EMAIL_USE_TLS=True
EMAIL_HOST="smtp.gmail.com"
EMAIL_HOST_USER="codespace"
EMAIL_HOST_USER="ssabadocs.786@gmail.com"
EMAIL_HOST_PASSWORD="nbax dnin aava zuql"
EMAIL_PORT=587
